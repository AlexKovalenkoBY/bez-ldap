<!-- src/components/Dashboard.vue -->
<template>
  <div>
    <h1>Dashboard</h1>
    <p>This is a protected route.</p>
  </div>
</template>

<script>
export default {
  name: 'Dashboard',
};
</script>